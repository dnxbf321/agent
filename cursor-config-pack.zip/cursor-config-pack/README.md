# Cursor 可迁移配置包

从 macOS + Cursor 环境导出的 IDE 配置，可用于新机器或团队成员快速还原开发环境。

**导出时间**: 2026-06-05
**源用户**: dengjiayao

---

## 目录结构

```
cursor-config-pack/
├── MANIFEST.json              # 包清单与元数据
├── README.md                  # 本文件
├── settings/
│   └── settings.json          # Cursor/VS Code 用户设置
├── keybindings/
│   └── keybindings.json       # 按键绑定
├── extensions/
│   ├── extensions.txt         # Marketplace 扩展 ID 列表
│   └── vsix/
│       └── README.md          # 内部 VSIX 安装说明
├── mcp/
│   └── mcp.json.template      # MCP 配置模板（含占位符）
├── cursor/
│   └── rules/                 # User Rules 文本（需手动导入）
├── project/
│   ├── .editorconfig          # 项目 EditorConfig 参考
│   └── .prettierrc            # 项目 Prettier 参考
└── scripts/
    └── install.sh             # 一键安装脚本 (macOS)
```

---

## 快速安装 (macOS)

```bash
cd cursor-config-pack
chmod +x scripts/install.sh

# 预览（不实际修改）
./scripts/install.sh --dry-run

# 正式安装
./scripts/install.sh
```

安装脚本会自动：

1. 备份并覆盖 `settings.json`、`keybindings.json`
2. 生成 `~/.cursor/mcp.json`（替换 `$HOME` 和开发者账号）
3. 通过 `cursor --install-extension` 安装 extensions.txt 中的扩展
4. 若 `extensions/vsix/` 下有 `.vsix`，自动安装

---

## 手动步骤

### 1. User Rules

打开 **Cursor Settings → Rules**，将 `cursor/rules/` 下各文件内容添加为 User Rule：

| 文件 | 说明 |
|------|------|
| `git-commit.md` | Git 提交安全协议 |
| `create-pull-request.md` | PR 创建流程 |
| `code-and-communication.md` | 代码与沟通规范 |
| `global-architect-zh.md` | 中文架构师全局规则 |
| `environment-and-skills.md` | 环境与 Skills 遵循 |

### 2. Superpowers Plugin

**Cursor Settings → Plugins** → 搜索 **Superpowers** → Install

提供 TDD、调试、brainstorming、writing-plans 等 14 个 skills。

---

## Windows / Linux 迁移

| 项 | macOS | Windows | Linux |
|----|-------|---------|-------|
| User 目录 | `~/Library/Application Support/Cursor/User` | `%APPDATA%\Cursor\User` | `~/.config/Cursor/User` |
| Cursor 目录 | `~/.cursor` | `%USERPROFILE%\.cursor` | `~/.cursor` |

手动复制文件时，将 `settings/`、`keybindings/` 内容放到对应 User 目录；`mcp.json.template` 替换占位符后存为 `~/.cursor/mcp.json`。

Windows 按键绑定中 `cmd` 需改为 `ctrl`（本包为 macOS 布局）。

---

## 自定义项（迁移前建议修改）

| 配置 | 位置 | 说明 |
|------|------|------|
| `psi-header` 作者 | `settings/settings.json` | `author` / `authorEmail` |
| 外部终端 | `settings/settings.json` | `terminal.external.osxExec: iTerm.app` |

---

## 打包与分发

```bash
# 创建 zip 包
cd ~
zip -r cursor-config-pack-2026-06-05.zip cursor-config-pack \
  -x "*.DS_Store" -x "*/vsix/*.vsix"

# 若需包含 yun-api VSIX（内部使用）
# cp /path/to/yun-api-generator-1.1.1.vsix cursor-config-pack/extensions/vsix/
```

---

## 验证清单

- [ ] 主题 `One Dark Pro Mix` + 图标 `Material Icon Theme` 正常
- [ ] `⇧⌘F` 格式化、`⇧⌥F` 全局搜索、`⇧⌘O` 整理 import
- [ ] MCP: playwright 在 Settings → MCP 中显示 Connected
- [ ] User Rules 5 条已导入
- [ ] Superpowers 插件已启用
- [ ] Prettier / ESLint 扩展正常工作

# yun-api-generator VSIX

此扩展为内部 VSIX 包，未发布到 Marketplace，需单独获取并安装。

## 安装步骤

1. 将 `yun-api-generator-1.1.1.vsix` 放入本目录
2. 执行：

```bash
cursor --install-extension ./yun-api-generator-1.1.1.vsix
```

3. 安装完成后，MCP 配置中的路径应为：

```
~/.cursor/extensions/undefined_publisher.yun-api-generator-1.1.1/dist/mcp-server.js
```

## 从源机器导出 VSIX

在已安装扩展的机器上：

```bash
# 方式一：从扩展目录打包（若扩展支持）
cd ~/.cursor/extensions/undefined_publisher.yun-api-generator-1.1.1
# 联系扩展维护者获取官方 VSIX

# 方式二：Cursor 命令面板
# Extensions: Install from VSIX...
```

> 当前配置包未包含 VSIX 文件本身，迁移时需自行拷贝。
